#if !defined(AFX_WBLINDSCTRLS_H__20020730_EA9C_5E94_AA49_0080AD509054__INCLUDED_)
#define AFX_WBLINDSCTRLS_H__20020730_EA9C_5E94_AA49_0080AD509054__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// Window Blinds controls
//
// SkinnedButton code originally from MFC sample 
// by Shinya Miyamoto (s-miya@ops.dti.ne.jp)
//
// Copyright (c) 2002 Bjarke Viksoe.
// Skinned button code: Copyright (c) 2000 Shinya Miyamoto
//
// This code may be used in compiled form in any way you desire. This
// source file may be redistributed by any means PROVIDING it is 
// not sold for profit without the authors written consent, and 
// providing that this notice and the authors name is included. 
//
// This file is provided "as is" with no expressed or implied warranty.
// The author accepts no liability if it causes any damage to you or your
// computer whatsoever. It's free, so don't hassle me about it.
//
// Beware of bugs.
//

#pragma once

#ifndef __cplusplus
  #error WTL requires C++ compilation (use a .cpp suffix)
#endif

#ifndef __ATLAPP_H__
  #error This control requires atlapp.h to be included first
#endif

#ifndef __ATLCTRLS_H__
  #error This control requires atlctrls.h to be included first
#endif


/////////////////////////////////////////////////////////////////////////////
// CWBButton - Window Blinds like button class
//
// Author: Shinya Miyamoto
// Email:  s-miya@ops.dti.ne.jp
// Copyright 2000, Shinya Miyamoto
//
// You may freely use or modify this code provided this
// Copyright is included in all derived versions.
//

template< class T, class TBase = CButton, class TWinTraits = CControlWinTraits >
class ATL_NO_VTABLE CSkinnedButtonImpl : 
   public CWindowImpl< T, TBase, TWinTraits >,
   public COwnerDraw< T >
{
public:
   typedef CSkinnedButtonImpl< T, TBase, TWinTraits > thisClass;

   DECLARE_WND_SUPERCLASS(NULL, TBase::GetWndClassName())

   CBitmap m_bmpNormal;
   CBitmap m_bmpPushed;
   CBitmap m_bmpFocus;
   CBitmap m_bmpDisabled;
   CBitmap m_bmpOver;
   HPALETTE m_hPalette;

   COLORREF m_clrText;
   COLORREF m_clrTransparent;
   POINT m_ptOffset;
   bool m_bIsCheckbox;
   bool m_bChecked;

   // Operations
   
   BOOL SubclassWindow(HWND hWnd)
   {
      BOOL bRet = CWindowImpl< T, TBase, TWinTraits >::SubclassWindow(hWnd);
      if( bRet ) _Init();
      return bRet;
   }
   void SetTextColor(COLORREF clrText)
   {
      ATLASSERT(::IsWindow(m_hWnd));
      m_clrText = clrText;
      Invalidate();
   }
   void SetTransparentColor(COLORREF clrColor)
   {
      ATLASSERT(::IsWindow(m_hWnd));
      m_clrTransparent = clrColor;
   }
   void SetPushOffset(POINT pt)
   {
      ATLASSERT(::IsWindow(m_hWnd));
      m_ptOffset = pt;
   }
   void SetPalette(HPALETTE hPalette)
   {
      ATLASSERT(::IsWindow(m_hWnd));
      m_hPalette = hPalette;
   }
   BOOL SetBitmap(UINT nRes, int nBitmaps = 5, LPRECT pRect = NULL)
   {
      ATLASSERT(::IsWindow(m_hWnd));
      CBitmap bmp;
      bmp = (HBITMAP) ::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(nRes), IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION);
      if( bmp.IsNull() ) return FALSE;
      if( !_CreateImage(m_bmpNormal,   bmp, 0, nBitmaps, pRect) ) return FALSE;
      if( !_CreateImage(m_bmpPushed,   bmp, 1, nBitmaps, pRect) ) return FALSE;
      if( !_CreateImage(m_bmpDisabled, bmp, 2, nBitmaps, pRect) ) return FALSE;
      if( nBitmaps > 3 ) if( !_CreateImage(m_bmpFocus, bmp, 3, nBitmaps, pRect) ) return FALSE;
      //if( nBitmaps > 5 ) if( !_CreateImage(m_bmpOver,  bmp, 5, nBitmaps, pRect) ) return FALSE;
      return TRUE;
   }
   HBITMAP GetBitmap() const
   {
      return NULL; // unsupported
   }
   UINT GetChecked() const
   {
      return m_bChecked ? BST_CHECKED : BST_UNCHECKED;
   }
   BOOL SetChecked(UINT uState)
   {
      ATLASSERT(::IsWindow(m_hWnd));
      if( !m_bIsCheckbox ) return FALSE;
      m_bChecked = uState==BST_CHECKED;
      Invalidate();
      return TRUE;
   }

   // Implementation
   
   void _Init()
   {
      // Ajust button styles before we make it ownerdrawn.
      // The ownerdrawn style would otherwise remove some of the
      // existing style customizations.
      DWORD dwStyle = GetStyle();
      switch( dwStyle & 0x0F ) {
      case BS_CHECKBOX:
      case BS_AUTOCHECKBOX:
         m_bIsCheckbox = true;
         m_bChecked = GetChecked() == BST_CHECKED;
         // See note in OnClicked() handler
         if( (dwStyle & 0x0F) == BS_AUTOCHECKBOX ) ModifyStyle(0, BS_MULTILINE);
         break;
      default:
         m_bIsCheckbox = false;
         m_bChecked = false;
      }

      // Finally make it owner-drawn
      ModifyStyle(0x0F, BS_OWNERDRAW);

      m_clrText = ::GetSysColor(COLOR_WINDOWTEXT);
      m_clrTransparent = RGB(255,0,255);
      m_ptOffset.x = 2;
      m_ptOffset.y = 2;
      m_hPalette = NULL;
   }

   BOOL _CreateImage(CBitmap& bmpDst, CBitmap& bmpSrc, int iIndex, int nNumImages, LPRECT prc) const
   {      
      if( !bmpDst.IsNull() ) bmpDst.DeleteObject();

      CClientDC dc(m_hWnd);

      RECT rcClient;
      GetClientRect(&rcClient);
      int cxClient = rcClient.right - rcClient.left;
      int cyClient = rcClient.bottom - rcClient.top;

      BITMAP info;
      bmpSrc.GetBitmap(&info);

      int cxImage = info.bmWidth / nNumImages;
      int cyImage = info.bmHeight;
      int x = cxImage * iIndex;

      RECT rcTemp;
      if( prc == NULL ) {
         // If not stretch-constraints are defined we
         // default to 1/4 of the button size.
         int cx = cxImage / 4;
         int cy = cyImage / 4;
         ::SetRect(&rcTemp, cx, cy, cx, cy);
         prc = &rcTemp;
      }

      CDC memDC;
      memDC.CreateCompatibleDC(dc);

      HPALETTE hOldPalette = NULL;
      if( m_hPalette != NULL ) {
         hOldPalette = memDC.SelectPalette(m_hPalette, FALSE);
         memDC.RealizePalette();
      }

      CDC srcDC;
      srcDC.CreateCompatibleDC(dc);
      HBITMAP hOldBmp1 = srcDC.SelectBitmap(bmpSrc);

      bmpDst.CreateCompatibleBitmap(dc, cxClient, cyClient);
      HBITMAP hOldBmp2 = memDC.SelectBitmap(bmpDst);

      // Copy the 4 corners as is...
      if( !memDC.BitBlt(0, 0, prc->left, prc->top, srcDC, x, 0, SRCCOPY) ) return FALSE;
      if( !memDC.BitBlt(0, cyClient - prc->bottom, prc->left, prc->bottom, srcDC, x, cyImage - prc->bottom, SRCCOPY) ) return FALSE;
      if( !memDC.BitBlt(cxClient- prc->right, 0, prc->right, prc->top, srcDC, x + cxImage - prc->right, 0, SRCCOPY) ) return FALSE;
      if( !memDC.BitBlt(cxClient - prc->right, cyClient - prc->bottom, prc->right, prc->bottom, srcDC, x + cxImage - prc->right, cyImage - prc->bottom, SRCCOPY) ) return FALSE;

      // Middle
      if( !memDC.StretchBlt(prc->left, prc->top, 
         cxClient - (prc->left + prc->right), cyClient - (prc->top + prc->bottom), 
         srcDC, 
         x + prc->left, prc->top, 
         cxImage - (prc->left + prc->right), cyImage - (prc->top + prc->bottom), 
         SRCCOPY) ) return FALSE;

      // The 4 sides (top, left, bottom, right)
      if( !memDC.StretchBlt(prc->left, 0, 
         cxClient - (prc->left + prc->right), prc->top, 
         srcDC, 
         x + prc->left, 0, 
         cxImage - (prc->left + prc->right), prc->top, 
         SRCCOPY) ) return FALSE;
      if( !memDC.StretchBlt(0, prc->top, 
         prc->left, cyClient - (prc->top + prc->bottom), 
         srcDC, 
         x, prc->top, 
         prc->left, cyImage - (prc->top + prc->bottom), 
         SRCCOPY) ) return FALSE;
      if( !memDC.StretchBlt(prc->left, cyClient - prc->top, 
         cxClient - (prc->left + prc->right), prc->bottom, 
         srcDC, 
         x + prc->left, cyImage - prc->bottom, 
         cxImage - (prc->left + prc->right), prc->bottom, 
         SRCCOPY) ) return FALSE;
      if( !memDC.StretchBlt(cxClient - prc->right, prc->top, 
         prc->right, cyClient - (prc->top + prc->bottom),
         srcDC, 
         x + cxImage - prc->right, prc->top, 
         prc->right, cyImage - (prc->top + prc->bottom), 
         SRCCOPY) ) return FALSE;

      memDC.SelectBitmap(hOldBmp2);
      srcDC.SelectBitmap(hOldBmp1);

      if( m_hPalette != NULL ) {
         memDC.SelectPalette(hOldPalette, FALSE);
         memDC.RealizePalette();
      }

      return TRUE;
   }

   BOOL _DrawImage(CDCHandle& dc, CBitmap& bmp, COLORREF clrTransparent) const
   {
      RECT rc;
      GetClientRect(&rc);

      // Copy image transparently.
      // Oh, all this copy-bitmap-here-select-bitmap-there is not my strong side, and
      // I wonder why the following Shinya Miyamoto code only takes up a fraction
      // of the official Microsoft code used in the KB article Q79212 ?!
      // Oh well... it probably works. To everyones joy, TransparentBlt() was available
      // since Windows 98! Too bad this code needs to work on Win95 as well :-(

      COLORREF clrOldBack = dc.SetBkColor(RGB(255,255,255));
      COLORREF clrOldText = dc.SetTextColor(RGB(0,0,0));

      HPALETTE hOldPalette = NULL;
      if( m_hPalette != NULL ) {
         hOldPalette = dc.SelectPalette(m_hPalette, FALSE);
         dc.RealizePalette();
      }

      CDC dcImage, dcTrans;

      // Create two memory dcs for the image and the mask
      dcImage.CreateCompatibleDC(dc);
      dcTrans.CreateCompatibleDC(dc);

      HBITMAP hOldBitmapImage  = dcImage.SelectBitmap(bmp);
      
      // Create the mask bitmap
      CBitmap bitmapTrans;
      int nWidth = rc.right - rc.left;
      int nHeight = rc.bottom - rc.top;
      bitmapTrans.CreateBitmap(nWidth, nHeight, 1, 1, NULL);

      // Select the mask bitmap into the appropriate dc
      HBITMAP hOldBitmapTrans = dcTrans.SelectBitmap(bitmapTrans);

      // Build mask based on transparent colour
      dcImage.SetBkColor(clrTransparent);
      dcTrans.BitBlt(0, 0, nWidth, nHeight, dcImage, 0, 0, SRCCOPY);

      // Do the work - True Mask method - cool if not actual display
      dc.BitBlt(0, 0, nWidth, nHeight, dcImage, 0, 0, SRCINVERT);
      dc.BitBlt(0, 0, nWidth, nHeight, dcTrans, 0, 0, SRCAND);
      dc.BitBlt(0, 0, nWidth, nHeight, dcImage, 0, 0, SRCINVERT);

      // Restore settings
      dcImage.SelectBitmap(hOldBitmapImage);
      dcTrans.SelectBitmap(hOldBitmapTrans);
      dc.SetBkColor(clrOldBack);
      dc.SetTextColor(clrOldText);
      if( m_hPalette != NULL ) {
         dc.SelectPalette(hOldPalette, FALSE);
         dc.RealizePalette();
      }

      return TRUE;
   }

   // Message map and handlers

   BEGIN_MSG_MAP(thisClass)
      MESSAGE_HANDLER(WM_CREATE, OnCreate)
      MESSAGE_HANDLER(WM_LBUTTONDBLCLK, OnLButtonDblClick)
      REFLECTED_COMMAND_CODE_HANDLER(BN_CLICKED, OnClicked)
      CHAIN_MSG_MAP_ALT( COwnerDraw< T >, 1 )
   END_MSG_MAP()

   LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {      
      LRESULT lRes = DefWindowProc();
      _Init();
      return lRes;
   }
   LRESULT OnLButtonDblClick(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/)
   {
      // HACK: Ideally we would remove the CS_DBLCLCKS class style, but since we're
      //       subclassing the control we're forced to make it act like a regular click.
      //       Otherwise double-clicks will not show the button as pushed.
      return DefWindowProc(WM_LBUTTONDOWN, wParam, lParam);
   }   
   LRESULT OnClicked(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& bHandled)
   {
      if( m_bIsCheckbox ) {
         // Use the BS_MULTILINE style instead of BS_AUTOCHECKBOX
         // because it got removed by BS_OWNERDRAW...
         if( (GetStyle() & BS_MULTILINE) == 0 ) {
            m_bChecked = !m_bChecked;
            Invalidate();
         }
      }
      bHandled = FALSE;
      return 0;
   }

   // Owner draw methods

   void DrawItem(LPDRAWITEMSTRUCT lpDIS)
   {
      CDCHandle dc = lpDIS->hDC;
      UINT& state = lpDIS->itemState;
      RECT& rc = lpDIS->rcItem;

      // Draw bitmap
      if( (state & ODS_SELECTED) || (m_bIsCheckbox && m_bChecked) ) { 
         _DrawImage( dc, m_bmpPushed, m_clrTransparent );
         rc.left += m_ptOffset.x;
         rc.top += m_ptOffset.y;
      }
      else if( state & ODS_DISABLED ) {
         _DrawImage( dc, m_bmpDisabled, m_clrTransparent );
      }
      else if( !m_bmpFocus.IsNull() && (state & ODS_FOCUS)!=0 ) {
         _DrawImage( dc, m_bmpFocus, m_clrTransparent );
      }
      else {
         _DrawImage( dc, m_bmpNormal, m_clrTransparent );
      }

      // Draw text
      TCHAR szText[128] = { 0 };
      GetWindowText(szText, (sizeof(szText)/sizeof(TCHAR))-1);

      dc.SetBkMode(TRANSPARENT);
      HFONT hOldFont = dc.SelectFont(GetFont());
      dc.SetTextColor( (state & ODS_DISABLED) == 0 ? m_clrText : ::GetSysColor(COLOR_GRAYTEXT) );
      dc.DrawText(szText, -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
      dc.SelectFont(hOldFont);
   }
};

class CSkinnedButtonCtrl : public CSkinnedButtonImpl<CSkinnedButtonCtrl>
{
public:
   DECLARE_WND_SUPERCLASS(_T("WTL_SkinnedButton"), GetWndClassName())
};



#endif // !defined(AFX_WBLINDSCTRLS_H__20020730_EA9C_5E94_AA49_0080AD509054__INCLUDED_)
